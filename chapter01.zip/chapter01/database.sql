CREATE SCHEMA `chapter01` DEFAULT CHARACTER SET utf8mb4 ;

CREATE TABLE `product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增 ID',
  `category` bigint(20) unsigned DEFAULT '0' COMMENT '分类',
  `name` varchar(45) DEFAULT '' COMMENT '产品名称',
  `intro` varchar(255) DEFAULT '' COMMENT '产品简介',
  `price` decimal(18,2) DEFAULT '0.00',
  `status` smallint(5) unsigned DEFAULT '1' COMMENT '状态 1：可用；2：不可用；',
  `created` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '新建时间',
  `updated` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品表';

CREATE TABLE `product_photo` (
  `id` bigint(20) unsigned NOT NULL COMMENT '自增 ID',
  `path` varchar(255) DEFAULT '' COMMENT '后缀路径',
  `seq` int(10) unsigned DEFAULT '1' COMMENT '序号',
  `created` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '新建时间',
  `updated` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品图片';