package model

// ProductPhoto 产品图片的结构体
type ProductPhoto struct {
	BaseModel
	ProductID int64  `db:"product_id" json:"productID"`
	Path      string `db:"path" json:"path"`
	Seq       int    `db:"seq" json:"seq"`
}

// ViewPhotoRespArgs 查看图片响应的结构体
type ViewPhotoRespArgs struct {
	ID   int64  `db:"id" json:"id,omitempty"`
	Path string `db:"path" json:"path"`
	URL  string `db:"url" json:"url"`
	Seq  int    `db:"seq" json:"seq"`
}

// UploadFileArgs 上传文件的请求结构体
type UploadFileArgs struct {
	File    []byte `json:"file"`
	FileExt string `json:"fileExt"`
	Seq     int    `json:"seq"`
}

// UploadPhotoRespArgs 完成上传图片后的响应结构体
type UploadPhotoRespArgs struct {
	Src   string `json:"src"`
	Small string `json:"small"`
	Big   string `json:"big"`
	Cut   string `json:"cut"`
	Seq   int    `json:"seq"`
}
