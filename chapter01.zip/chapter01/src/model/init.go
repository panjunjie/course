package model

import (
	"time"
)

// JSONTime 重写了 time.Time JSON 的序列函数
type JSONTime time.Time

// String  打印输出字符串
func (t JSONTime) String() string {
	return time.Time(t).Format("2006-01-02 15:04:05")
}

// MarshalText 序列化
func (t JSONTime) MarshalText() ([]byte, error) {
	return []byte(`"` + t.String() + `"`), nil
}

// MarshalJSON JSON 序列化输出
func (t JSONTime) MarshalJSON() ([]byte, error) {
	return t.MarshalText()
}

// UnmarshalJSON JSON 反序列化
func (t *JSONTime) UnmarshalJSON(data []byte) error {
	dt, err := time.ParseInLocation(`2006-01-02 15:04:05`, string(data), time.Local)
	if err != nil {
		return err
	}

	*t = JSONTime(dt)
	return nil
}

// BaseModel 基类结构体
type BaseModel struct {
	ID      int64     `db:"id" json:"id"`
	Created *JSONTime `db:"created" json:"created"`
	Updated *JSONTime `db:"updated" json:"updated"`
}

// ServiceResponse 响应主体结构体
type ServiceResponse struct {
	Code     int         `json:"code"`
	ErrorMsg string      `json:"errorMsg"`
	Body     interface{} `json:"body,omitempty"`
}
