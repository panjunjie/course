package model

// Product 产品结构体
type Product struct {
	BaseModel
	Category int64   `db:"category" json:"category"`
	Name     string  `db:"name" json:"name"`
	Intro    string  `db:"intro" json:"intro"`
	Price    float64 `db:"price" json:"price"`
	Status   int     `db:"status" json:"status"`
}

// ProductExt 产品扩展结构体
type ProductExt struct {
	Product
	Photos []ViewPhotoRespArgs `json:"photos"`
}
