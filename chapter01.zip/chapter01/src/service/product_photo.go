package service

import (
	"chapter01/src/common"
	"chapter01/src/model"
)

// UploadProductPhoto 上传产品图片
func UploadProductPhoto(file []byte, fileExt string, seq int) (retData model.ServiceResponse) {
	if file == nil {
		return SetServiceResponse(common.Code1003, "缺少文件数据")
	}

	if seq <= 0 {
		seq = 1
	}

	localUploadHandler := common.LocalUploadHandler{}
	retImageData, err := localUploadHandler.UploadImage(file, fileExt, seq, "product")
	if err != nil && retImageData == nil {
		common.ShowErr(err)
		return SetServiceResponse(common.CodeFailure, "文件上传失败！")
	}

	return ServiceResponseSuccess(retImageData)
}
