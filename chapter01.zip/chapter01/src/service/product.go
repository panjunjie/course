package service

import (
	"chapter01/src/common"
	"chapter01/src/dao"
	"chapter01/src/model"
	"chapter01/src/util"
)

// ProductList 根据分类获取产品列表
func ProductList(category int64, key string, start, end uint64) (retData model.ServiceResponse) {
	params := model.Product{}
	params.Status = 1
	if category > 0 {
		params.Category = category
	}

	if key != "" {
		params.Name = key
		params.Intro = key
	}

	page := util.NewPaginate(start, end)
	productList, err := dao.SelectProductListByModel(sqlxDB, params, "", page.GetPageIndex(), page.GetPageSize())
	if err != nil {
		common.ShowErr(err)
		return ServiceResponseFailure()
	}

	productExtList := []model.ProductExt{}
	for i, s := 0, len(productList); i < s; i++ {
		productExt := model.ProductExt{
			Product: productList[i],
			Photos:  getProductPhotosByProductID(productList[i].BaseModel.ID),
		}
		productExtList = append(productExtList, productExt)
	}

	return ServiceResponseSuccess(productExtList)
}

// ProductDetail 产品详情页
func ProductDetail(productID int64) (retData model.ServiceResponse) {
	if productID <= 0 {
		return SetServiceResponseCode(common.Code1003)
	}

	product, err := dao.SelectProductByID(sqlxDB, productID)
	if err != nil {
		common.ShowErr(err)
		return ServiceResponseFailure()
	}

	photos := getProductPhotosByProductID(product.ID)
	productExt := model.ProductExt{
		Product: *product,
		Photos:  photos,
	}

	return ServiceResponseSuccess(productExt)
}

// ProductAddNew 新增一个产品
func ProductAddNew(category int64, name, intro string, price float64, photoEdit []model.ViewPhotoRespArgs) (retData model.ServiceResponse) {
	if category <= 0 {
		return SetServiceResponseCode(common.Code1003)
	}

	if name == "" || intro == "" {
		return SetServiceResponseCode(common.Code1003)
	}

	if price <= 0 {
		return SetServiceResponseCode(common.Code1003)
	}

	product := model.Product{
		Category: category,
		Name:     name,
		Intro:    intro,
		Price:    price,
		Status:   1,
	}

	productID, err := dao.InsertProduct(sqlxDB, product)
	if err != nil {
		common.ShowErr(err)
		return ServiceResponseFailure()
	}

	// 新增图片记录
	for i, s := 0, len(photoEdit); i < s; i++ {
		productPhoto := model.ProductPhoto{
			ProductID: productID,
			Seq:       photoEdit[i].Seq,
			Path:      photoEdit[i].Path,
		}
		_, err = dao.InsertProductPhoto(sqlxDB, productPhoto)
		if err != nil {
			common.ShowErr(err)
		}
	}

	return ServiceResponseSuccess()
}

// ProductModify 修改一个产品
func ProductModify(productID int64, category int64, name, intro string, price float64, photoEdit []model.ViewPhotoRespArgs) (retData model.ServiceResponse) {
	if productID <= 0 {
		return SetServiceResponseCode(common.Code1003)
	}

	product := model.Product{
		BaseModel: model.BaseModel{ID: productID},
		Category:  category,
		Name:      name,
		Intro:     intro,
		Price:     price,
	}

	_, err := dao.UpdateProduct(sqlxDB, product)
	if err != nil {
		common.ShowErr(err)
		return ServiceResponseFailure()
	}

	// TODO 图片的处理上有更好的办法，后期补充
	// 删除所有图片记录
	dao.DeleteProductPhotoByModel(sqlxDB, model.ProductPhoto{
		ProductID: productID,
	})

	// 新增图片记录
	for i, s := 0, len(photoEdit); i < s; i++ {
		_, err = dao.InsertProductPhoto(sqlxDB, model.ProductPhoto{
			ProductID: productID,
			Seq:       photoEdit[i].Seq,
			Path:      photoEdit[i].Path,
		})
		if err != nil {
			common.ShowErr(err)
		}
	}

	return ServiceResponseSuccess()
}

// ProductDelete 删除一个产品
func ProductDelete(productID int64) (retData model.ServiceResponse) {
	if productID <= 0 {
		return SetServiceResponseCode(common.Code1003)
	}

	_, err := dao.DeleteProductByID(sqlxDB, productID)
	if err != nil {
		common.ShowErr(err)
		return ServiceResponseFailure()
	}

	return ServiceResponseSuccess()
}

// getProductPhotosByProductID 内部函数 ：根据产品 ID 获取产品的所有图片
func getProductPhotosByProductID(productID int64) []model.ViewPhotoRespArgs {
	productArgs, err := dao.SelectProductPhotoListByProductID(sqlxDB, productID)
	if err != nil {
		common.ShowErr(err)
		return productArgs
	}

	for i, s := 0, len(productArgs); i < s; i++ {
		productArgs[i].URL = common.GetMediaURL(productArgs[i].URL)
	}

	return productArgs
}
