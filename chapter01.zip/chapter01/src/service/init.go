package service

import (
	"chapter01/src/common"
	"chapter01/src/dbutil"
	"chapter01/src/model"
	"github.com/jmoiron/sqlx"
)

var (
	sqlxDB *sqlx.DB
)

func init() {
	sqlxDB = dbutil.SQLXDB
	if sqlxDB == nil {
		sqlxDB = dbutil.NewSQLXDB()
	}
}

// serviceResponseSuccess 只简单返回成功
func ServiceResponseSuccess(body ...interface{}) model.ServiceResponse {
	return SetServiceResponseCode(common.CodeSuccess, body...)
}

// serviceResponseFailure 只简单返回操作失败
func ServiceResponseFailure() model.ServiceResponse {
	return SetServiceResponseCode(common.CodeFailure)
}

// setServiceResponseCode 响应主体结构体
func SetServiceResponseCode(resultCode int, body ...interface{}) model.ServiceResponse {
	return SetServiceResponse(resultCode, common.CodeMsgMap[resultCode], body...)
}

// setServiceResponse 响应主体结构体
func SetServiceResponse(resultCode int, errMsg string, body ...interface{}) (respBody model.ServiceResponse) {
	respBody.Code = resultCode
	respBody.ErrorMsg = errMsg
	if len(body) > 0 {
		respBody.Body = body[0]
	}
	return respBody
}
