package common

import (
	"errors"
	"strings"

	"chapter01/src/model"
	"chapter01/src/util"
)

const (
	fileSeq = "/"
)

// UploadHandler 上传文件接口
type UploadHandler interface {
	//上传图片文件，返回 原图 大图 小图 切图 的前缀路径
	UploadImage(file []byte, ext string, seq int, folder ...string) (*model.UploadPhotoRespArgs, error)
	// 上传文件，返回文件的前缀路径
	UploadFile(file []byte, ext string, seq int, folder ...string) string
	// 删除一个文件
	DeleteFile(suffPath string) bool
}

// LocalUploadHandler 本地上传文件接口
type LocalUploadHandler struct {
}

// UploadImage 上传图片
func (h *LocalUploadHandler) UploadImage(file []byte, ext string, seq int, folder ...string) (*model.UploadPhotoRespArgs, error) {
	if file == nil || ext == "" {
		return nil, errors.New("file or ext is empty")
	}

	ext = "." + ext
	tmpFileName := util.GenFileName()
	tmpFilePath := GetConfString("default", "media_path")

	// 临时文件
	tmpFullPath := tmpFilePath + fileSeq + tmpFileName + ext
	err := util.BytesToFile(file, tmpFullPath)
	if err != nil {
		return nil, err
	}

	//ShowInfo(tmpFilePath)

	fileName := util.GenFileName()
	filePath := GetConfString("default", "media_path")
	fileSrcName := fileName + "_src" + ext
	fileBigName := fileName + "_b" + ext
	fileSmallName := fileName + "_s" + ext
	fileCutName := fileName + "_c" + ext

	// 绝对路径
	absFolderPathBuf := strings.Builder{}
	absFolderPathBuf.WriteString(filePath + fileSeq)
	for i, s := 0, len(folder); i < s; i++ {
		absFolderPathBuf.WriteString(folder[i] + fileSeq)
	}
	absFolderPath := absFolderPathBuf.String()
	//检查新建文件夹
	util.CheckCreatePath(absFolderPath)

	absSrcFullPath := absFolderPath + fileSrcName
	absBigFullPath := absFolderPath + fileBigName
	absSmallFullPath := absFolderPath + fileSmallName
	absCutFullPath := absFolderPath + fileCutName

	// 虚拟路径
	virFolderPathBuf := strings.Builder{}
	virFolderPathBuf.WriteString(fileSeq)
	for i, s := 0, len(folder); i < s; i++ {
		virFolderPathBuf.WriteString(folder[i] + fileSeq)
	}
	virFolderPath := virFolderPathBuf.String()

	virSrcFullPath := virFolderPath + fileSrcName
	virBigFullPath := virFolderPath + fileBigName
	virSmallFullPath := virFolderPath + fileSmallName
	virCutFullPath := virFolderPath + fileCutName

	util.ImageResize(tmpFullPath, 1080, 1920, absSrcFullPath)
	util.ImageResize(tmpFullPath, 750, 1344, absBigFullPath)
	util.ImageResize(tmpFullPath, 640, 1136, absSmallFullPath)
	util.ImageCut(tmpFullPath, 400, 400, absCutFullPath)

	data := model.UploadPhotoRespArgs{}
	data.Seq = seq
	data.Src = virSrcFullPath
	data.Big = virBigFullPath
	data.Small = virSmallFullPath
	data.Cut = virCutFullPath

	// 删除临时的文件
	util.DeleteFile(tmpFullPath)

	return &data, nil
}

// UploadFile 上传文件
func (h *LocalUploadHandler) UploadFile(file []byte, ext string, seq int, folder ...string) string {
	return ""
}

// DeleteFile 删除图片
func (h *LocalUploadHandler) DeleteFile(suffPath string) bool {
	if suffPath == "" {
		return false
	}

	filePath := GetConfString("default", "media_path")

	// 删除临时文件
	util.DeleteFile(filePath + strings.Replace(suffPath, "_b", "_src", -1))
	util.DeleteFile(filePath + strings.Replace(suffPath, "_b", "_s", -1))
	util.DeleteFile(filePath + strings.Replace(suffPath, "_b", "_c", -1))
	util.DeleteFile(filePath + suffPath)

	return true
}
