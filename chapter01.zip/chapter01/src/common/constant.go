package common

const (
	// DatetimeDefaultFmt 时间默认格式
	DatetimeDefaultFmt = "2006-01-02 15:04:05"
	// DatetimeFullFmt 时间默认格式
	DatetimeFullFmt = "2006-01-02 15:04:05.999"
	// DatetimeFullFmt2 时间默认格式
	DatetimeFullFmt2 = "2006-01-02 15:04:05.99999"
	// DateDefaultFmt 时间默认格式
	DateDefaultFmt = "2006-01-02"
	// DatetimeZhCNFmt 中文时间默认格式
	DatetimeZhCNFmt = "2006年01月02日 15:04:05"
	// DateZhCNFmt 中文日期默认格式
	DateZhCNFmt = "2006年01月02日"
	// CharSetDefault 默认字符编码
	CharSetDefault = "UTF-8"
	// RemoteAddrDefault 默认 IP
	RemoteAddrDefault = "127.0.0.1"
)

const (
	// CodeSuccess 成功 code key
	CodeSuccess = 1
	// CodeFailure code key
	CodeFailure = 0
	// Code1000 code key
	Code1000 = 1000
	// Code1001 code key
	Code1001 = 1001
	// Code1002 code key
	Code1002 = 1002
	// Code1003 code key
	Code1003 = 1003
	// Code1004 code key
	Code1004 = 1004
	// Code1005 code key 仅支持POST请求!
	Code1005 = 1005

	// MsgEmpty 空字符串
	MsgEmpty = ""
	// MsgFailure 操作失败！
	MsgFailure = "操作失败！"
	// Msg1001 程序內部异常！
	Msg1001 = "程序內部异常！"
	// Msg1002 数据库异常！
	Msg1002 = "数据库异常！"
	// Msg1003 缺少参数！
	Msg1003 = "缺少参数！"
	// Msg1004 参数格式有误!
	Msg1004 = "参数格式有误!"
	// Msg1005 仅支持POST请求!
	Msg1005 = "仅支持POST请求!"
)

var (
	// CodeMsgMap map code and msg
	CodeMsgMap = map[int]string{
		CodeSuccess: MsgEmpty,
		CodeFailure: MsgFailure,
		Code1001:    Msg1001,
		Code1002:    Msg1002,
		Code1003:    Msg1003,
		Code1004:    Msg1004,
		Code1005:    Msg1005,
	}
)
