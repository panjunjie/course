package common

import (
	"github.com/sirupsen/logrus"
)

func init() {
	logrus.SetFormatter(&logrus.TextFormatter{})
	logrus.SetReportCaller(true)

	debug := GetConfBool("default", "dev_mode")
	if debug {
		logrus.SetFormatter(&logrus.JSONFormatter{})
		logrus.SetLevel(logrus.DebugLevel)
	}
}

// FatalErr 打印致命错误，程序终止
func FatalErr(args ...interface{}) {
	if len(args) > 0 {
		logrus.Fatal(args)
	}
}


// ShowErr 打印严重错误
func ShowErr(args ...interface{}) {
	if len(args) > 0 {
		logrus.Error(args)
	}
}

// ShowDebug 打印 Debug 信息
func ShowDebug(args ...interface{}) {
	if len(args) > 0 {
		logrus.Debug(args)
	}
}

// ShowInfo 打印信息
func ShowInfo(args ...interface{}) {
	if len(args) > 0 {
		logrus.Info(args)
	}
}
