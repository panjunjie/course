package common

import (
	"strings"
)

// GetMediaURL 获取媒体文件的 URL 全路径
func GetMediaURL(path string) string {
	if path == "" {
		return ""
	}

	if !strings.HasPrefix(path, "/") {
		path = "/" + path
	}

	mediaURL := GetConfString("default", "media_url")
	if mediaURL == "" {
		return ""
	}

	if !strings.HasSuffix(mediaURL, "/") {
		mediaURL = strings.TrimRight(mediaURL, "/")
	}

	return mediaURL + path
}
