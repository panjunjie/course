package common

import (
	"github.com/robfig/config"
)

const (
	configPathDefault = "config.ini"
)

var (
	//ConfigKit 配置文件工具
	ConfigKit *config.Config
)

func init() {
	LoadConfigure()
}

// LoadConfigure 加载获取配置文件
func LoadConfigure() {
	if ConfigKit == nil {
		var err error
		ConfigKit, err = config.ReadDefault(configPathDefault)
		if err != nil {
			FatalErr("获取配置文件 config.ini 失败", err.Error())
		}
	}
}

//GetConfString 获取配置文件的某个字符串配置属性
func GetConfString(section, option string) string {
	v, err := ConfigKit.String(section, option)
	if err != nil {
		ShowErr(err)
		return ""
	}
	return v
}

//GetConfInt 获取配置文件的某个数值配置属性
func GetConfInt(section, option string) int {
	v, err := ConfigKit.Int(section, option)
	if err != nil {
		ShowErr(err)
		return 0
	}
	return v
}

// GetConfBool 获取配置文件的某个布朗配置属性
func GetConfBool(section, option string) bool {
	v, err := ConfigKit.Bool(section, option)
	if err != nil {
		ShowErr(err)
		return false
	}
	return v
}
