package test

import (
	"chapter01/src/model"
	"chapter01/src/util"
)

const (
	testDomain             = "http://localhost:3000"
	applicationJSONCharSet = "application/json;charset=utf-8"
)

var (
	allTestCaseReq = map[string]TestCaseReq{}
)

// ALLTestCaseReqData 全部测试案例请求数据
func ALLTestCaseReqData() map[string]TestCaseReq {

	allTestCaseReq["pathProductList"] = TestCaseReq{
		Name: "产品列表",
		URL:  testDomain + "/api/v1/product/list",
		Params: map[string]interface{}{
			"category": 1,
			"start":    1,
			"end":      10,
		},
	}

	allTestCaseReq["pathProductDetail"] = TestCaseReq{
		Name: "产品详情页",
		URL:  testDomain + "/api/v1/product/detail",
		Params: map[string]interface{}{
			"productID": 1,
		},
	}

	allTestCaseReq["pathProductSearch"] = TestCaseReq{
		Name: "产品搜索",
		URL:  testDomain + "/api/v1/product/search",
		Params: map[string]interface{}{
			"category": 1,
			"key":      "语言",
			"start":    1,
			"end":      10,
		},
	}

	allTestCaseReq["pathProductAdd"] = TestCaseReq{
		Name: "新增一个产品",
		URL:  testDomain + "/api/v1/product/add",
		Params: map[string]interface{}{
			"category": 1,
			"name":     "Go",
			"intro":    "Go 语言的圣经书籍，年度畅销书籍",
			"price":    56.98,
			"photoEdit": []model.ViewPhotoRespArgs{model.ViewPhotoRespArgs{
				Path: "/product/154192547123856140062_b.png",
				Seq:  1,
			}, model.ViewPhotoRespArgs{
				Path: "/product/154192547123856140062_b.png",
				Seq:  2,
			}, model.ViewPhotoRespArgs{
				Path: "/product/154192547123856140062_b.png",
				Seq:  3}},
		},
	}

	allTestCaseReq["pathProductModify"] = TestCaseReq{
		Name: "修改一个产品",
		URL:  testDomain + "/api/v1/product/modify",
		Params: map[string]interface{}{
			"productID": 3,
			"category":  1,
			"name":      "Go",
			"intro":     "Go 语言的圣经书籍，年度畅销书籍666",
			"price":     56.98,
			"photoEdit": []model.ViewPhotoRespArgs{model.ViewPhotoRespArgs{
				ID:   1,
				Path: "/product/154192547123856140062_b.png",
				Seq:  1,
			}, model.ViewPhotoRespArgs{
				ID:   2,
				Path: "/product/154192547123856140062_b.png",
				Seq:  2,
			}, model.ViewPhotoRespArgs{
				ID:   3,
				Path: "/product/154192547123856140062_b.png",
				Seq:  3}},
		},
	}

	allTestCaseReq["pathProductDelete"] = TestCaseReq{
		Name: "删除一个产品",
		URL:  testDomain + "/api/v1/product/delete",
		Params: map[string]interface{}{
			"productID": 3,
		},
	}

	allTestCaseReq["pathProductPhotoUpload"] = TestCaseReq{
		Name: "产品图片上传",
		URL:  testDomain + "/api/v1/product/photo/upload",
		Params: map[string]interface{}{
			"file":    util.PathToBytes("D:\\t.png"),
			"fileExt": "png",
			"seq":     1,
		},
	}

	return allTestCaseReq
}
