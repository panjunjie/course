package test

import "time"

// TestCaseReq 测试案例请求结构体
type TestCaseReq struct {
	Name   string
	URL    string
	Params map[string]interface{}
}

// TestCaseResp 测试案例请响应结构体
type TestCaseResp struct {
	Name     string
	URL      string
	ReqJSON  string
	RespJSON string
	TimeMs   time.Duration
}
