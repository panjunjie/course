package test

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"time"

	"chapter01/src/common"
)

// PostTestCaseDataToServer 发送 POST 测试案例请求的函数
func PostTestCaseDataToServer(testCaseReq TestCaseReq) *TestCaseResp {
	start := time.Now()

	bytParams, err := json.Marshal(testCaseReq.Params)
	if err != nil {
		common.ShowErr(err)
		return nil
	}

	body := bytes.NewBuffer(bytParams)
	req, err := http.NewRequest("POST", testCaseReq.URL, body)
	if err != nil {
		common.ShowErr(err)
		return nil
	}
	req.Header.Set("Content-Type", applicationJSONCharSet)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		common.ShowErr(err)
		return nil
	}
	defer resp.Body.Close()

	respJSON, _ := ioutil.ReadAll(resp.Body)

	testCaseResp := TestCaseResp{
		Name:     testCaseReq.Name,
		URL:      testCaseReq.URL,
		ReqJSON:  string(bytParams),
		RespJSON: string(respJSON),
		TimeMs:   time.Since(start),
	}

	return &testCaseResp
}
