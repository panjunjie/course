package util

const (
	charsetDefault = "UTF-8"
)

var (
	charsetUTF8 = "charset=" + charsetDefault
	// MimeFORM form 的 mime 类型
	MimeFORM = "application/x-www-form-urlencoded" + "; " + charsetUTF8
	// MimeFORMDATA Form data 的 mime 类型
	MimeFORMDATA = "multipart/form-data" + "; " + charsetUTF8
	// MimeJSON JSON 的 mime 类型
	MimeJSON = "application/json" + "; " + charsetUTF8
	// MimeXML XML 的 mime 类型
	MimeXML = "application/xml" + "; " + charsetUTF8
	// MimeHTML HTML 的 mime 类型
	MimeHTML = "text/html" + "; " + charsetUTF8
)
