package util

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"
)

// SendHTTPGet 发起 HTTP GET 请求
func SendHTTPGet(url string) string {
	resp, err := http.Get(url)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return ""
	}
	return string(body)
}

// SendHTTPPost 发起 HTTP POST 请求
func SendHTTPPost(url string, param string, mime string) string {
	resp, err := http.Post(url, mime, strings.NewReader(param))
	if err != nil {
		return ""
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return ""
	}
	return string(body)
}

// SendHTTPPostForm 发起 HTTP POST 表单请求
func SendHTTPPostForm(url string, urlValue url.Values) string {
	resp, err := http.PostForm(url, urlValue)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return ""
	}
	return string(body)
}

// SendHTTPDo 发起 HTTP Do 详细请求
func SendHTTPDo(url string, method string, params string, mime string, header map[string]string, cookie string) string {
	req, err := http.NewRequest(method, url, strings.NewReader(params))
	if err != nil {
		return ""
	}
	req.Header.Set("Content-Type", mime)
	req.Header.Set("Cookie", cookie)

	if header != nil && len(header) > 0 {
		for k, v := range header {
			req.Header.Set(k, v)
		}
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return ""
	}

	return string(body)
}

// SendHTTPPostTest 发起 HTTP POST 请求
func SendHTTPPostTest(url string, param map[string]interface{}) string {
	reqJSONByt, err := json.Marshal(param)
	if err != nil {
		log.Println(err)
	}

	log.Println("请求参数：")
	log.Println(string(reqJSONByt))

	resp, err := http.Post(url, MimeJSON, bytes.NewReader(reqJSONByt))
	if err != nil {
		return ""
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return ""
	}

	respJSON := string(body)

	log.Println("响应参数：")
	log.Println(respJSON)

	return respJSON
}
