package util

import (
	"html/template"
	"time"

	"github.com/unrolled/render"
)

var (
	r          *render.Render
	renderUtil *RenderUtil
)

// NewRender 实例化一个渲染类结构体
func NewRender(debug bool, templateDir string) *RenderUtil {
	renderUtil = &RenderUtil{
		debug:       debug,
		templateDir: templateDir,
	}

	return renderUtil
}

// ClassicRender 实例化一个渲染类结构体
func ClassicRender() *RenderUtil {
	return NewRender(false, "template")
}

// RenderUtil 渲染类结构体
type RenderUtil struct {
	debug       bool
	templateDir string
}

// InitRender 初始化一个 render.Render 实例
func (renderUtil *RenderUtil) InitRender() *render.Render {
	if r == nil {
		r = render.New(render.Options{
			Directory:                 renderUtil.templateDir,                 // Specify what path to load the templates from.
			Layout:                    "",                                     // Specify a layout template. Layouts can call {{ yield }} to render the current template.
			Extensions:                []string{".html", ".tmpl"},             // Specify extensions to load for templates.
			Funcs:                     []template.FuncMap{AppHelpers},         // Specify helper function maps for templates to access.
			Delims:                    render.Delims{Left: "{{", Right: "}}"}, // Sets delimiters to the specified strings.
			Charset:                   charsetDefault,                         // Sets encoding for json and html content-types. Default is "UTF-8".
			IndentJSON:                renderUtil.debug,                       // Output human readable JSON.
			IndentXML:                 renderUtil.debug,                       // Output human readable XML.
			PrefixJSON:                []byte(""),                             // Prefixes JSON responses with the given bytes.
			PrefixXML:                 []byte(""),                             // Prefixes XML responses with the given bytes.
			HTMLContentType:           "text/html",                            // Output XHTML content type instead of default "text/html".
			IsDevelopment:             renderUtil.debug,                       // Render will now recompile the templates on every HTML response.
			UnEscapeHTML:              true,                                   // Replace ensure '&<>' are output correctly (JSON only).
			StreamingJSON:             true,                                   // Streams the JSON response via json.Encoder.
			RequirePartials:           true,                                   // Return an error if a template is missing a partial used in a layout.
			DisableHTTPErrorRendering: !renderUtil.debug,                      // Disables automatic rendering of http.StatusInternalServerError when an error occurs.
		})
	}

	return r
}

//AppHelpers 定义 template.FuncMap 方法集合
var AppHelpers = template.FuncMap{
	"html": func(x string) interface{} {
		return template.HTML(x)
	},
	"add": func(a, b int) int {
		return a + b
	},
	"subt": func(a, b int) int {
		return a - b
	},
	"currentTime": func(fm string) interface{} {
		return time.Now().Format(fm)
	},
	"timeFormat": func(datetime time.Time, format string) interface{} {
		return datetime.Format(format)
	},
	"timeFormat2": func(t int64, format string) interface{} {
		if t > 0 {
			return time.Unix(t, 0).Format(format)
		}
		return "1970-01-01 00:00:00"
	},
}
