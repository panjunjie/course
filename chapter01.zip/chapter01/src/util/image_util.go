package util

import (
	"io/ioutil"
	"log"
	"net/http"

	"github.com/disintegration/imaging"
)

// ImageResize 指定宽高比例缩放图片
func ImageResize(srcFileName string, width, height int, targetFileName string) {
	// Open the test image.
	src, err := imaging.Open(srcFileName)
	if err != nil {
		log.Fatalf("Open failed: %v", err)
	}

	// Resize the cropped image to width = 256px preserving the aspect ratio.
	dst := imaging.Resize(src, 0, height, imaging.Lanczos)

	// Save the resulting image using JPEG format.
	err = imaging.Save(dst, targetFileName)
	if err != nil {
		log.Fatalf("Save failed: %v", err)
	}
}

// ImageCut 指定宽高剪切图片
func ImageCut(srcFileName string, width, height int, targetFileName string) {
	// Open the test image.
	src, err := imaging.Open(srcFileName)
	if err != nil {
		log.Fatalf("Open failed: %v", err)
	}

	// Resize the cropped image to width = 256px preserving the aspect ratio.
	dst := imaging.Fill(src, width, height, imaging.Center, imaging.Lanczos)

	// Save the resulting image using JPEG format.
	err = imaging.Save(dst, targetFileName)
	if err != nil {
		log.Fatalf("Save failed: %v", err)
	}
}

// GetWebImage 从网络上下载图片
func GetWebImage(imageURL string) (byt []byte) {
	resp, err := http.Get(imageURL)
	if err != nil {
		log.Println("GetWebImage 获取网络图片失败" + err.Error())
	}
	byt, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println("下载的图片转换为字节码失败！" + err.Error())
	}
	return byt
}
