package util

import (
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"os"
	"path"
	"strings"
	"time"
)

// FileToBytes 把文件 File 转成字节数组 []byte
func FileToBytes(file *os.File) []byte {
	if nil == file {
		return nil
	}

	bytes, err := ioutil.ReadAll(file)
	if nil != err {
		log.Println(err)
	}
	return bytes
}

// PathToBytes 传入文件路径，转成字节数组
func PathToBytes(filename string) []byte {
	exists, err := PathExists(filename)
	if err != nil || !exists {
		return nil
	}

	bytes, err := ioutil.ReadFile(filename)
	if nil != err {
		log.Println(err)
	}
	return bytes
}

// ReadFile 小文件推荐一次性读取，这样程序更简单，而且速度最快。
func ReadFile(filePath string) ([]byte, error) {
	f, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	return ioutil.ReadAll(f)
}

// ReadFileToBytes 小文件推荐一次性读取，这样程序更简单，而且速度最快。
func ReadFileToBytes(filePath string) []byte {
	byt, err := ReadFile(filePath)
	if err != nil {
		log.Println(err)
		return nil
	}
	return byt
}

// ReadFileToString 小文件推荐一次性读取，这样程序更简单，而且速度最快。
func ReadFileToString(filePath string) string {
	byt, err := ReadFile(filePath)
	if err != nil {
		return ""
	}
	return string(byt)
}

// BytesToFile 把字节数组转成文件
func BytesToFile(byt []byte, filename string) error {
	//如果文件夹不存在，则新建文件夹
	CheckCreatePath(GetFilePath(filename))
	return ioutil.WriteFile(filename, byt, 0777)
}

// CheckCreatePath 检查文件夹是否存在，不存在则新建该文件夹
func CheckCreatePath(path string) {
	exists, err := PathExists(path)
	if !exists {
		os.Mkdir(path, 0777)
	} else {
		if err != nil {
			os.Mkdir(path, 0777)
		}
	}
}

// GetFileExt 获取文件后缀
func GetFileExt(fullFileName string) string {
	if "" == fullFileName {
		return ""
	}
	return strings.ToLower(path.Ext(fullFileName))
}

// GetFilePath 返回路径的路径
func GetFilePath(fullFileName string) string {
	if fullFileName != "" {
		fullFileName = path.Dir(fullFileName)
	}
	return fullFileName
}

// GetFileName 获取文件名
func GetFileName(fullFileName string) string {
	if "" == fullFileName {
		return ""
	}
	filenameWithSuffix := path.Base(fullFileName)                              //获取文件名带后缀
	fileSuffix := path.Ext(filenameWithSuffix)                                 //获取文件后缀
	return strings.ToLower(strings.TrimSuffix(filenameWithSuffix, fileSuffix)) //获取文件名
}

// GenFileName 生成文件名（不包括后缀）
func GenFileName() string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	return fmt.Sprintf("%d%d", time.Now().UnixNano(), r.Intn(100))
}

// PathExists 检查文件路径是否存在
func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

// DeleteFile 删除文件
func DeleteFile(path string) {
	exists, err := PathExists(path)
	if err == nil && exists {
		if GetFileExt(path) != "" {
			//一定有后缀的文件才删除
			err := os.Remove(path)
			if nil != err {
				log.Println(err)
			}
		}

	}
}

// ReadAll 读取小文件到内存
func ReadAll(filePth string) ([]byte, error) {
	f, err := os.Open(filePth)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	return ioutil.ReadAll(f)
}

// MoveFile 重命名文件
func MoveFile(fromPath, targetPath string) {
	err := os.Rename(fromPath, targetPath)
	fmt.Println(err)
}
