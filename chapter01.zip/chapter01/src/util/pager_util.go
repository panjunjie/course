package util

// Paginate 分页结构体
type Paginate struct {
	Start     uint64 // 开始索引 从1开始
	End       uint64 // 结束索引 包括自身
	RowsCount uint64 // 总行数
}

// NewPaginate 实例化一个 Paginate 结构体
func NewPaginate(start, end uint64) *Paginate {
	if start >= end {
		start = 1
		end = 10
	}

	p := &Paginate{
		Start:     start,
		End:       end,
		RowsCount: 0,
	}
	return p
}

// GetPageIndex 获取当前页索引
func (p *Paginate) GetPageIndex() uint64 {
	return p.Start - 1
}

// GetPageSize 获取每页记录数
func (p *Paginate) GetPageSize() uint64 {
	return p.End - p.Start + 1
}

// GetTotalPage 获取总页数
func (p *Paginate) GetTotalPage() uint64 {
	if p.RowsCount > 0 {
		var t uint64
		if p.RowsCount%uint64(p.GetPageSize()) > 0 {
			t = 1
		}
		return uint64(p.RowsCount/uint64(p.GetPageSize()) + t)
	}
	return p.RowsCount
}

// GetPageCount 根据记录总数和页数尺寸，获取总页数；外部方法
func GetPageCount(rowsCount uint64, pageSize uint64) (pageCount uint64) {
	if rowsCount <= 0 || pageSize <= 0 {
		return 0
	}

	pageCount = rowsCount / pageSize
	pageRemainder := rowsCount % pageSize
	if pageCount <= 0 {
		return 1
	}

	if pageRemainder > 0 {
		return pageCount + 1
	}
	return pageCount
}
