package controller

import (
	"encoding/json"
	"net/http"

	"chapter01/src/common"
	"chapter01/src/model"
	"chapter01/src/service"
)

// ProductList 产品列表
func ProductList(w http.ResponseWriter, req *http.Request) {
	reqJSON := requestJSON(req)
	respBody := service.ProductList(reqJSON.Get("category").Int(), "", reqJSON.Get("start").Uint(), reqJSON.Get("end").Uint())
	r.JSON(w, http.StatusOK, respBody)
	return
}

// ProductSearch 关键字搜索产品
func ProductSearch(w http.ResponseWriter, req *http.Request) {
	reqJSON := requestJSON(req)
	respBody := service.ProductList(reqJSON.Get("category").Int(), reqJSON.Get("key").String(), reqJSON.Get("start").Uint(), reqJSON.Get("end").Uint())
	r.JSON(w, http.StatusOK, respBody)
	return
}

// ProductDetail 产品详情
func ProductDetail(w http.ResponseWriter, req *http.Request) {
	reqJSON := requestJSON(req)
	respBody := service.ProductDetail(reqJSON.Get("productID").Int())
	r.JSON(w, http.StatusOK, respBody)
	return
}

// ProductAddNew 新增一个产品
func ProductAddNew(w http.ResponseWriter, req *http.Request) {
	reqJSON := requestJSON(req)

	photoEditJSON := reqJSON.Get("photoEdit").String()
	var photoEdit []model.ViewPhotoRespArgs
	if photoEditJSON != "" {
		json.Unmarshal([]byte(photoEditJSON), &photoEdit)
	}

	respBody := service.ProductAddNew(
		reqJSON.Get("category").Int(),
		reqJSON.Get("name").String(),
		reqJSON.Get("intro").String(),
		reqJSON.Get("price").Float(),
		photoEdit,
	)
	r.JSON(w, http.StatusOK, respBody)
	return
}

// ProductModify 修改一个产品
func ProductModify(w http.ResponseWriter, req *http.Request) {
	reqJSON := requestJSON(req)

	photoEditJSON := reqJSON.Get("photoEdit").String()
	var photoEdit []model.ViewPhotoRespArgs
	if photoEditJSON != "" {
		json.Unmarshal([]byte(photoEditJSON), &photoEdit)
	}

	respBody := service.ProductModify(
		reqJSON.Get("productID").Int(),
		reqJSON.Get("category").Int(),
		reqJSON.Get("name").String(),
		reqJSON.Get("intro").String(),
		reqJSON.Get("price").Float(),
		photoEdit,
	)
	r.JSON(w, http.StatusOK, respBody)
	return
}

// ProductDelete 删除一个产品，包括产品图片
func ProductDelete(w http.ResponseWriter, req *http.Request) {
	reqJSON := requestJSON(req)
	respBody := service.ProductDelete(reqJSON.Get("productID").Int())
	r.JSON(w, http.StatusOK, respBody)
	return
}

// UploadProductPhoto 上传一张产品图片
func UploadProductPhoto(w http.ResponseWriter, req *http.Request) {
	reqJSONString := requestJSONString(req)
	var uploadFileArgs model.UploadFileArgs
	err := json.Unmarshal([]byte(reqJSONString), &uploadFileArgs)
	if err != nil {
		common.ShowErr(err)
		serviceResp := model.ServiceResponse{
			Code:     common.CodeFailure,
			ErrorMsg: common.MsgFailure,
		}
		r.JSON(w, http.StatusOK, serviceResp)
		return
	}

	respBody := service.UploadProductPhoto(
		uploadFileArgs.File,
		uploadFileArgs.FileExt,
		uploadFileArgs.Seq,
	)
	r.JSON(w, http.StatusOK, respBody)
	return
}
