package controller

import (
	"chapter01/src/service"
	"net/http"
	"strings"

	"github.com/tidwall/gjson"
	"github.com/unrolled/render"

	"chapter01/src/common"
	"chapter01/src/util"
)

const (
	//ApplicationJSON 应用程序 JSON 格式
	applicationJSON = "application/json"
)

var (
	debug                  = common.GetConfBool("default", "dev_mode")
	r                      *render.Render
	applicationJSONCharSet = applicationJSON + ";charset=" + common.CharSetDefault
)

func init() {
	r = util.NewRender(debug, "template").InitRender()
}

func requestJSON(req *http.Request) gjson.Result {
	jsonString := requestJSONString(req)
	jsonResult := gjson.Result{}
	if jsonString != "" {
		jsonResult = gjson.Parse(jsonString)
	}

	return jsonResult
}

// requestJSONString 直接获取 请求参数是 JSON 的字符串
func requestJSONString(req *http.Request) string {
	return util.RequestJSON(req)
}

func RendJSON(w http.ResponseWriter, req *http.Request, v interface{}) {
	r.JSON(w, http.StatusOK, v)
}

// CheckParamsMiddleware 检查公共参数
func CheckParamsMiddleware(w http.ResponseWriter, req *http.Request, next http.HandlerFunc) {
	//白名单地址，一般都是 GET 请求的地址
	if chkWhiteURI(req) {
		next(w, req)
		return
	}

	if strings.ToUpper(req.Method) != "POST" {
		serviceResp := service.SetServiceResponseCode(common.Code1005)
		RendJSON(w, req, serviceResp)
		return
	}

	next(w, req)
	return
}

//检查给的后缀地址是否为白名单地址（一般都是 GET 请求，不需要传公共参数）
func chkWhiteURI(req *http.Request) bool {
	requestURI := req.RequestURI
	if strings.ToUpper(req.Method) == "GET" && (strings.HasSuffix(requestURI, ".html") || strings.HasSuffix(requestURI, ".htm")) {
		return true
	}

	arr := []string{"/test"}
	for i, l := 0, len(arr); i < l; i++ {
		if strings.HasPrefix(requestURI, arr[i]) {
			return true
		}
		continue
	}
	return false
}
