package controller

import (
	"net/http"

	"chapter01/src/test"
)

// RunTestIndex 循环罗列所有的接口链接
func RunTestIndex(w http.ResponseWriter, req *http.Request) {
	ctx := map[string]interface{}{}
	ctx["allTestCaseReq"] = test.ALLTestCaseReqData()
	r.HTML(w, http.StatusOK, "run_api_test_index", ctx)
	return
}

// RunTestResult 显示 POST 请求后的结果页面
func RunTestResult(w http.ResponseWriter, req *http.Request) {
	key := req.FormValue("key")
	testCaseReqData := test.ALLTestCaseReqData()[key]
	testCaseResp := test.PostTestCaseDataToServer(testCaseReqData)
	ctx := map[string]interface{}{}
	ctx["testCaseResp"] = testCaseResp
	r.HTML(w, http.StatusOK, "run_api_test_result", ctx)
	return
}
