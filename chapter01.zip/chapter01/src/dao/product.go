package dao

import (
	"errors"
	"github.com/jmoiron/sqlx"
	"time"

	sq "github.com/elgris/sqrl"

	"chapter01/src/model"
)

// SelectProductByID 根据 ID 获取单个 Product 对象
func SelectProductByID(sqlxDB *sqlx.DB, id int64) (*model.Product, error) {
	var product model.Product
	err := sqlxDB.Get(&product, "select * from product where id=? limit 1", id)
	if err != nil {
		return nil, err
	}

	return &product, nil
}

// SelectProductListByModel 根据实体（动态条件）获取多个 Product 对象集合
func SelectProductListByModel(sqlxDB *sqlx.DB, params model.Product, orderBy string, pageIndex, pageSize uint64) ([]model.Product, error) {
	sqlBuild := sq.Select("*").From("product")
	if params.BaseModel.ID > 0 {
		sqlBuild.Where("id=?", params.ID)
	}

	if params.Status > 0 {
		sqlBuild.Where("status=?", params.Status)
	}

	if params.Category > 0 {
		sqlBuild.Where("category=?", params.Category)
	}

	if params.Name != "" && params.Intro != "" {
		sqlBuild.Where(sq.Expr("name like ? or intro like ?", `%`+params.Name+`%`, `%`+params.Intro+`%`))
	} else {
		if params.Name != "" {
			sqlBuild.Where("name LIKE ?", `%`+params.Name+`%`)
		}

		if params.Intro != "" {
			sqlBuild.Where("intro LIKE ?", `%`+params.Intro+`%`)
		}
	}

	if orderBy != "" {
		sqlBuild.OrderBy(orderBy)
	} else {
		sqlBuild.OrderBy("id desc")
	}

	if pageIndex > 0 && pageSize > 0 {
		sqlBuild.Offset(pageIndex).Limit(pageSize)
	}

	query, args, err := sqlBuild.ToSql()
	if err != nil {
		return nil, err
	}
	//ShowInfo(query)

	var list []model.Product
	err = sqlxDB.Select(&list, query, args...)
	if err != nil {
		return list, err
	}

	return list, nil
}

// SelectProductCountByModel 根据实体(动态条件）获取 Product 对象集合数量
func SelectProductCountByModel(sqlxDB *sqlx.DB, params model.Product) (int64, error) {
	sqlBuild := sq.Select("count(*)").From("product")
	if params.BaseModel.ID > 0 {
		sqlBuild.Where("id=?", params.ID)
	}

	if params.Status > 0 {
		sqlBuild.Where("status=?", params.Status)
	}

	if params.Category > 0 {
		sqlBuild.Where("category=?", params.Category)
	}

	if params.Name != "" && params.Intro != "" {
		sqlBuild.Where(sq.Expr("name like ? or intro like ?", `%`+params.Name+`%`, `%`+params.Intro+`%`))
	} else {
		if params.Name != "" {
			sqlBuild.Where("name LIKE ?", `%`+params.Name+`%`)
		}

		if params.Intro != "" {
			sqlBuild.Where("intro LIKE ?", `%`+params.Intro+`%`)
		}
	}

	query, args, err := sqlBuild.ToSql()
	if err != nil {
		return 0, err
	}
	var cnt int64
	err = sqlxDB.Get(&cnt, query, args...)
	if err != nil {
		return 0, err
	}

	return cnt, nil
}

// DeleteProductByID 根据 ID 删除一个 Product 记录
func DeleteProductByID(sqlxDB *sqlx.DB, id int64) (rowsAffected int64, err error) {
	result, err := sqlxDB.Exec("delete from product where id=?", id)
	if err != nil {
		return 0, err
	}

	rowsAffected, err = result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return
}

// DeleteProductByModel 根据实体(动态条件） 删除一个或多个 Product 记录
func DeleteProductByModel(sqlxDB *sqlx.DB, params model.Product) (rowsAffected int64, err error) {
	sqlBuild := sq.Delete("product")
	if params.BaseModel.ID > 0 {
		sqlBuild.Where("id=?", params.ID)
	}

	if params.Status > 0 {
		sqlBuild.Where("status=?", params.Status)
	}

	if params.Category > 0 {
		sqlBuild.Where("category=?", params.Category)
	}

	if params.Name != "" {
		sqlBuild.Where("name LIKE ?", `%`+params.Name+`%`)
	}

	if params.Intro != "" {
		sqlBuild.Where("intro LIKE ?", `%`+params.Intro+`%`)
	}

	query, args, err := sqlBuild.ToSql()
	if err != nil {
		return 0, err
	}

	if len(args) <= 0 {
		return 0, errors.New("args count le zero")
	}

	result, err := sqlxDB.Exec(query, args...)
	if err != nil {
		return 0, err
	}

	rowsAffected, err = result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return
}

//InsertProduct 新增一条产品记录
func InsertProduct(sqlxDB *sqlx.DB, params model.Product) (id int64, err error) {
	result, err := sqlxDB.Exec(
		`insert into product 
		(category,name,intro,price,status,created,updated) 
		values 
		(?,?,?,?,?,?,?)`,
		params.Category,
		params.Name,
		params.Intro,
		params.Price,
		params.Status,
		time.Now(),
		time.Now(),
	)
	if err != nil {
		return 0, err
	}

	id, err = result.LastInsertId()
	if err != nil {
		return 0, err
	}
	return
}

//UpdateProduct 更新一个产品信息，params.ID 是必须的
func UpdateProduct(sqlxDB *sqlx.DB, params model.Product) (rowsAffected int64, err error) {
	if params.ID <= 0 {
		return 0, errors.New("id le zero")
	}

	sqlBuild := sq.Update("product").Set("updated", time.Now())
	if params.Category > 0 {
		sqlBuild.Set("category", params.Category)
	}

	if params.Status > 0 {
		sqlBuild.Set("status", params.Status)
	}

	if params.Price > 0 {
		sqlBuild.Set("price", params.Price)
	}

	if params.Name != "" {
		sqlBuild.Set("name", params.Name)
	}

	if params.Intro != "" {
		sqlBuild.Set("intro", params.Intro)
	}

	query, args, err := sqlBuild.Where("id=?", params.ID).ToSql()
	if err != nil {
		return 0, err
	}

	result, err := sqlxDB.Exec(query, args...)
	if err != nil {
		return 0, err
	}

	rowsAffected, err = result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return
}
