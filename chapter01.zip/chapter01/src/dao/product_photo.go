package dao

import (
	"errors"
	"github.com/jmoiron/sqlx"
	"time"

	sq "github.com/elgris/sqrl"

	"chapter01/src/model"
)

// SelectProductPhotoByID 根据 ID 获取单个 ProductPhoto 对象
func SelectProductPhotoByID(sqlxDB *sqlx.DB, id int64) (*model.ProductPhoto, error) {
	var ProductPhoto model.ProductPhoto
	err := sqlxDB.Get(&ProductPhoto, "select * from product_photo where id=? limit 1", id)
	if err != nil {
		return nil, err
	}

	return &ProductPhoto, nil
}

// SelectProductPhotoListByModel 根据实体（动态条件）获取多个 ProductPhoto 对象集合
func SelectProductPhotoListByModel(sqlxDB *sqlx.DB, params model.ProductPhoto, orderBy string, pageIndex, pageSize uint64) ([]model.ProductPhoto, error) {
	sqlBuild := sq.Select("*").From("product_photo")
	if params.BaseModel.ID > 0 {
		sqlBuild.Where("id=?", params.ID)
	}

	if params.ProductID > 0 {
		sqlBuild.Where("product_id=?", params.ProductID)
	}

	if orderBy != "" {
		sqlBuild.OrderBy(orderBy)
	} else {
		sqlBuild.OrderBy("id desc")
	}

	if pageIndex > 0 && pageSize > 0 {
		sqlBuild.Offset(pageIndex).Limit(pageSize)
	}

	query, args, err := sqlBuild.ToSql()
	if err != nil {
		return nil, err
	}

	list := []model.ProductPhoto{}
	err = sqlxDB.Select(&list, query, args...)
	if err != nil {
		return list, err
	}

	return list, nil
}

// SelectProductPhotoListByProductID 根据实体（动态条件）获取多个 ProductPhoto 对象集合
func SelectProductPhotoListByProductID(sqlxDB *sqlx.DB, productID int64) ([]model.ViewPhotoRespArgs, error) {
	list := []model.ViewPhotoRespArgs{}
	err := sqlxDB.Select(&list, "select id,path,seq from product_photo where product_id=? order by seq asc,id desc ", productID)
	if err != nil {
		return list, err
	}

	return list, nil
}

// SelectProductPhotoCountByModel 根据实体(动态条件）获取 ProductPhoto 对象集合数量
func SelectProductPhotoCountByModel(sqlxDB *sqlx.DB, params model.ProductPhoto) (int64, error) {
	sqlBuild := sq.Select("count(*)").From("product_photo")
	if params.ID > 0 {
		sqlBuild.Where("id=?", params.ID)
	}

	if params.ProductID > 0 {
		sqlBuild.Where("product_id=?", params.ProductID)
	}

	query, args, err := sqlBuild.ToSql()
	if err != nil {
		return 0, err
	}
	var cnt int64
	err = sqlxDB.Get(&cnt, query, args...)
	if err != nil {
		return 0, err
	}

	return cnt, nil
}

// DeleteProductPhotoByID 根据 ID 删除一个 ProductPhoto 记录
func DeleteProductPhotoByID(sqlxDB *sqlx.DB, id int64) (rowsAffected int64, err error) {
	result, err := sqlxDB.Exec("delete from product_photo where id=?", id)
	if err != nil {
		return 0, err
	}

	rowsAffected, err = result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return
}

// DeleteProductPhotoByModel 根据实体(动态条件） 删除一个或多个 ProductPhoto 记录
func DeleteProductPhotoByModel(sqlxDB *sqlx.DB, params model.ProductPhoto) (rowsAffected int64, err error) {
	sqlBuild := sq.Delete("product_photo")
	if params.BaseModel.ID > 0 {
		sqlBuild.Where("id=?", params.ID)
	}

	if params.ProductID > 0 {
		sqlBuild.Where("product_id=?", params.ProductID)
	}

	query, args, err := sqlBuild.ToSql()
	if err != nil {
		return 0, err
	}

	if len(args) <= 0 {
		return 0, errors.New("args count le zero")
	}

	result, err := sqlxDB.Exec(query, args...)
	if err != nil {
		return 0, err
	}

	rowsAffected, err = result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return
}

//InsertProductPhoto 新增一条产品记录
func InsertProductPhoto(sqlxDB *sqlx.DB, params model.ProductPhoto) (id int64, err error) {
	result, err := sqlxDB.Exec(
		`insert into product_photo (product_id,path,seq,created,updated) values (?,?,?,?,?)`,
		params.ProductID,
		params.Path,
		params.Seq,
		time.Now(),
		time.Now(),
	)
	if err != nil {
		return 0, err
	}

	id, err = result.LastInsertId()
	if err != nil {
		return 0, err
	}
	return
}

//UpdateProductPhoto 更新一个产品信息，params.ID 是必须的
func UpdateProductPhoto(sqlxDB *sqlx.DB, params model.ProductPhoto) (rowsAffected int64, err error) {
	if params.ID <= 0 {
		return 0, errors.New("id le zero")
	}

	sqlBuild := sq.Update("product_photo").Set("updated", time.Now())
	if params.ProductID > 0 {
		sqlBuild.Set("product_id", params.ProductID)
	}

	if params.Path != "" {
		sqlBuild.Set("path", params.Path)
	}

	if params.Seq > 0 {
		sqlBuild.Set("seq", params.Seq)
	}

	query, args, err := sqlBuild.Where("id=?", params.ID).ToSql()
	if err != nil {
		return 0, err
	}

	result, err := sqlxDB.Exec(query, args...)
	if err != nil {
		return 0, err
	}

	rowsAffected, err = result.RowsAffected()
	if err != nil {
		return 0, err
	}
	return
}
