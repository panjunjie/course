package dao

import (
	"chapter01/src/common"
)

// FatalErr 打印致命错误，程序终止
func FatalErr(args ...interface{}) {
	common.FatalErr(args)
}

// ShowErr 打印严重错误
func ShowErr(args ...interface{}) {
	common.ShowErr(args)
}

// ShowDebug 打印 Debug 信息
func ShowDebug(args ...interface{}) {
	common.ShowDebug(args)
}

// ShowInfo 打印信息
func ShowInfo(args ...interface{}) {
	common.ShowInfo(args)
}
