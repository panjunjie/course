/*
				  _ooOoo_
				 o8888888o
				 88" . "88
				 (| -_- |)
				 O\  =  /O
			  ____/`---'\____
			.'  \\|     |//  `.
		   /  \\|||  :  |||//  \
		  /  _||||| -:- |||||-  \
		  |   | \\\  -  /// |   |
		  | \_|  ''\---/''  |   |
		  \  .-\__  `-`  ___/-. /
		___`. .'  /--.--\  `. . __
	 ."" '<  `.___\_<|>_/___.'  >'"".
	| | :  `- \`.;`\ _ /`;.`/ - ` : | |
	\  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
				  `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
              佛祖保佑  永无BUG
*/

// 项目直接启动类
package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"time"

	"github.com/urfave/negroni"

	"chapter01/src/common"
	"chapter01/src/controller"
)

func main() {
	router := http.NewServeMux()

	router.HandleFunc("/", func(w http.ResponseWriter, req *http.Request) {
		fmt.Fprintf(w, "Welcome to chapter01 project.")
	})

	router.HandleFunc("/api/v1/product/list", controller.ProductList)
	router.HandleFunc("/api/v1/product/search", controller.ProductSearch)
	router.HandleFunc("/api/v1/product/detail", controller.ProductDetail)
	router.HandleFunc("/api/v1/product/add", controller.ProductAddNew)
	router.HandleFunc("/api/v1/product/modify", controller.ProductModify)
	router.HandleFunc("/api/v1/product/delete", controller.ProductDelete)
	router.HandleFunc("/api/v1/product/photo/upload", controller.UploadProductPhoto)

	n := negroni.New(negroni.NewRecovery())

	debug := common.GetConfBool("default", "dev_mode")
	if debug {
		//测试页面
		router.HandleFunc("/test/index", controller.RunTestIndex)
		router.HandleFunc("/test/result", controller.RunTestResult)
		n.Use(negroni.NewLogger())
		n.Use(negroni.NewStatic(http.Dir(".")))
	}

	//所有的地址都要检查公共参数是否合法
	n.Use(negroni.HandlerFunc(controller.CheckParamsMiddleware))
	n.UseHandler(router)

	timeOut := time.Second * 45

	srv := &http.Server{
		Addr:           ":3001",
		Handler:        n,
		ReadTimeout:    timeOut,
		WriteTimeout:   timeOut,
		IdleTimeout:    timeOut * 2,
		MaxHeaderBytes: 1 << 20,
	}

	go func() {
		if err := srv.ListenAndServe(); err != nil {
			log.Fatalf("listen and serve http server fail:\n %v ", err)
		}
	}()

	exit := make(chan os.Signal)
	signal.Notify(exit, os.Interrupt)
	<-exit
	ctx, cancel := context.WithTimeout(context.Background(), timeOut)
	defer cancel()
	err := srv.Shutdown(ctx)
	log.Println("shutting down now. ", err)
	os.Exit(0)
}
